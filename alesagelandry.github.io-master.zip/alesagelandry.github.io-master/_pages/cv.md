---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---



[pdf](http://alesagelandry.github.io/CV_ALesageLandry.pdf)
