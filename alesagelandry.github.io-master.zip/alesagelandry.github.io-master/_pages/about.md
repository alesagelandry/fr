---
permalink: /
title: "About me"
excerpt: "About me"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

I received the B.Eng. degree in Engineering Physics from École Polytechnique de Montréal, QC, Canada, in 2015, and the Ph.D. degree in Electrical Engineering from the University of Toronto, ON, Canada, in 2019. 

I am currently a Postdoctoral Scholar in the Energy & Resources Group at the University of California, Berkeley, CA, USA. My research interests include optimization, online learning and their applications to power system operations.
